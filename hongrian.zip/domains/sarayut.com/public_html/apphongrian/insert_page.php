<?php
  session_start();
  error_reporting(0);
  if($_SESSION['UserID'] == "")
  {
    echo "<script>alert('Please Login !!'); location.href='login_page.php';</script>";
    exit();
  }
?>
<!DOCTYPE html>



<html >
<head>
  <meta charset="UTF-8">
  <title>Admin Page</title>
  
  
  <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css'>

  <link rel="stylesheet" href="css/style_admin.css">

  <script type="text/javascript" src="ckeditor/ckeditor.js"></script>

  <meta name="viewport" content="width=device-width, initial-scale=1">

  
</head>

<body>
  <header role="banner">
  <h1>Insert Page</h1>
  <ul class="utilities">

    
    <li class="logout warn"><a href="logout.php">Log Out</a></li>
  </ul>
</header>

<nav role='navigation'>
  <ul class="main">
    <li class="users"><a href="admin_page.php">Main</a></li>
    <li class="write"><a href="insert_page.php">Insert Building</a></li>
    <li class="edit"><a href="edit_page.php">Edit Building</a></li>
    <li class="write"><a href="insert_page_classroom.php">Insert Classroom</a></li>
    <li class="edit"><a href="edit_page_classroom.php">Edit Classroom</a></li>
    <li class="view"><a href="index.php">View Website</a></li>

</nav>

<main role="main">
  <section class="panel important">
    <h2>Write a post</h2>

  <form name="form1" method="post" action="upload.php" enctype="multipart/form-data">
      <div class="twothirds">



      Place Name :      <input type="text" name="txtPlaceName"><br><br>
      Place Latitude :  <input type="text" name="txtPlacelat"><br><br>
      Place Longitude : <input type="text" name="txtplacelong"><br><br>
      
                      <input name="btnSubmit" type="submit" value="Submit">




  </form>




    
       

      </div>

    
          

        
    
  </section>


 


</main>
  
  
</body>
</html>
